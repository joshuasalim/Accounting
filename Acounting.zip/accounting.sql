-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: accounting
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chart`
--

DROP TABLE IF EXISTS `chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart` (
  `chart_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chart_name` varchar(45) NOT NULL,
  `chart_comment` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`chart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6011 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart`
--

LOCK TABLES `chart` WRITE;
/*!40000 ALTER TABLE `chart` DISABLE KEYS */;
INSERT INTO `chart` VALUES (1010,'cash',''),(1020,'bank',''),(1030,'account receivable',''),(1050,'tax out',''),(2020,'account payable',''),(2051,'tax in',' '),(4010,'sales income',''),(4020,'sales discount',''),(4030,'sales return',''),(5110,'purchasing',''),(5120,'purchasing discount',''),(5130,'purchasing return',''),(5210,'beginning inventory',''),(5220,'ending inventory',''),(6010,'general expenditure','');
/*!40000 ALTER TABLE `chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `det` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'123456789','Jln.Ansari No.55','UPH','1998-11-30'),(5,'04239589','asidhas','AN','2014-06-13'),(6,'04239589','asidhas','AB','2014-06-13'),(8,'04239589','asidhas','Ab','2014-06-13'),(9,'04239589','asidhas','Joshua','2014-06-13');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `inventory_id` varchar(10) NOT NULL,
  `jurnal_date` date NOT NULL,
  `jurnal_id` varchar(45) NOT NULL,
  `product_name` varchar(45) NOT NULL,
  `p_qty` int(10) unsigned NOT NULL,
  `p_price` double unsigned NOT NULL,
  `p_value` double unsigned NOT NULL,
  `s_qty` int(10) unsigned NOT NULL,
  `s_price` double unsigned NOT NULL,
  `s_value` double unsigned NOT NULL,
  `type` varchar(45) NOT NULL,
  `people` varchar(45) NOT NULL,
  `discount` double NOT NULL,
  `tax` double NOT NULL,
  `price` double unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES ('S0','2010-10-01','J1','pen',0,0,0,49,1000,49000,'sales','UPH',0,0,1000),('S0','1998-08-08','J1','buku',0,0,0,10,990,9900,'sales','UPH',10,10,1000),('S0','1998-08-31','J2','pen',0,0,0,10,1000,10000,'sales','asd',0,0,1000),('S0','1998-08-17','J3','buku',0,0,0,10,1000,10000,'sales','UPH',0,0,1000),('S0','1998-08-18','J4','pen',0,0,0,4,1000,4000,'sales','UPH',0,0,1000),('S0','1998-08-17','J5','buku',0,0,0,10,1000,10000,'sales','asd',0,0,1000),('S0','1998-08-20','J6','buku',0,0,0,10,10000,100000,'sales','A',0,0,10000),('P1','1999-09-10','J1','buku',10,1000,10000,0,0,0,'purchase','erik',0,0,1000),('P1','1999-09-11','J2','pen',10,1000,10000,0,0,0,'purchase','justin',0,0,1000),('P2','1999-09-13','J3','pen',10,1000,10000,0,0,0,'purchase','hary',0,0,1000),('P3','1999-09-15','J4','pen',10,1000,10000,0,0,0,'purchase','rt',0,0,1000),('P4','1999-09-19','J5','pen',10,1000,10000,0,0,0,'purchase','kel',0,0,1000),('P5','1999-09-17','J6','buku',10,2000,20000,0,0,0,'purchase','kel',0,0,2000),('P6','1999-09-19','J7','pen',100,2000,200000,0,0,0,'purchase','oo',0,0,2000),('P7','1999-09-20','J8','pen',100,200,20000,0,0,0,'purchase','o',0,0,200),('P8','1999-09-21','J9','pen',10,10000,100000,0,0,0,'purchase','k',0,0,10000),('P9','1999-09-28','J10','pen',10,1000,10000,0,0,0,'purchase','kel',0,0,1000),('P10','1999-09-29','J11','pen',20,1000,20000,0,0,0,'purchase','erik',0,0,1000),('S0','1998-08-31','J7','pen',0,0,0,1000,100,100000,'sales','AN',0,0,100),('S1','2017-07-01','J1','pen',0,0,0,10,1000,10000,'sales','AN',0,0,1000),('P1','2011-11-01','J1','buku',100,9900,990000,0,0,0,'purchase','erik',10,10,10000),('S1','2011-11-02','J2','buku',0,0,0,50,14850,742500,'sales','AN',10,10,15000),('P1','2012-12-01','J1','pen',100,10000,1000000,0,0,0,'purchase','jo',0,0,10000),('S1','2012-12-01','J2','pen',0,0,0,20,20000,400000,'sales','asd',0,0,20000),('S1','2011-11-14','J3','buku',0,0,0,10,99,990,'sales','Ab',10,10,100),('P1','1997-07-01','J1','pen',100,10000,1000000,0,0,0,'purchase','PISI',0,0,10000),('P1','1997-07-01','J1','buku',100,10000,1000000,0,0,0,'purchase','PISI',0,0,10000),('S1','1997-07-02','J2','Botol',0,0,0,10,1000,10000,'sales','Anj',0,0,1000),('P2','1997-07-05','J3','Botol',100,9900,990000,0,0,0,'purchase','PISI',10,10,10000),('S1','1999-09-29','J1','Pen',0,0,0,10,990,9900,'sales','UPH',10,10,1000),('S1','1999-09-12','J2','Botol',0,0,0,10,8800,88000,'sales','UPH',20,10,10000),('S1','1999-09-12','J1','Botol',0,0,0,100,9.9,990,'sales','UPH',10,10,10),('P1','1999-09-01','J1','Buku',10,9900,99000,0,0,0,'purchase','KIKI',10,10,10000),('S1','1999-09-12','J2','Botol',0,0,0,10,20000,200000,'sales','AN',0,0,20000),('S1','1999-09-21','J3','Botol',0,0,0,2,10000,20000,'sales','UPH',0,0,10000),('P2','1999-09-18','J4','Pen',100,10000,1000000,0,0,0,'purchase','PISI',0,0,10000),('P3','1999-09-25','J5','Pensil',50,4950,247500,0,0,0,'purchase','Hardy',10,10,5000),('P4','1999-09-14','J6','Botol',100,5000,500000,0,0,0,'purchase','Hardy',0,0,5000),('P5','1999-09-14','J7','Pensil',100,9.9,990,0,0,0,'purchase','PISI',10,10,10),('P1','2018-08-01','J1','Buku',100,990,99000,0,0,0,'purchase','KIKI',10,10,1000),('S1','2018-08-02','J2','Buku',0,0,0,10,500,5000,'sales','UPH',0,0,500),('P1','2017-07-01','J1','Botol',100,990,99000,0,0,0,'purchase','KIKI',10,10,1000),('P1','2019-09-01','J1','Botol',100,990,99000,0,0,0,'purchase','KIKI',10,10,1000);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `i_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` varchar(10) NOT NULL,
  `jurnal_date` date NOT NULL,
  `jurnal_id` varchar(10) NOT NULL,
  `payment_id` varchar(10) NOT NULL,
  PRIMARY KEY (`i_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,'P1','1999-09-01','J1','Y1'),(2,'S1','1999-09-12','J2','Y2'),(3,'S1','1999-09-21','J3','Y2'),(4,'P2','1999-09-18','J4','Y2'),(5,'P3','1999-09-25','J5','Y3'),(6,'P4','1999-09-14','J6','Y4'),(7,'P5','1999-09-14','J7','Y5'),(8,'P1','2018-08-01','J1','Y1'),(9,'S1','2018-08-02','J2','Y2'),(10,'P1','2017-07-01','J1','Y1'),(11,'P1','2019-09-01','J1','Y1');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journals` (
  `det` date DEFAULT NULL,
  `jurnal` varchar(100) DEFAULT NULL,
  `chart` varchar(100) DEFAULT NULL,
  `chartname` varchar(100) DEFAULT NULL,
  `debit` double DEFAULT NULL,
  `credit` double DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES ('1998-10-30','1','1010','Account Receivable',0,12000,'sale1'),('2017-07-08','2','1010','Cash',1998,0,'purchase'),('2017-07-07','3','1020','Bank',0,2145,'sale'),('1998-10-30','1','1010','cash',12000,0,'sale1'),('1998-10-30','1','1010','Bank',120000,0,'sale1'),('1998-10-30','1','1010','Account Receivable',120000,50000,'sale1'),('2015-10-16','4','1010','Cash',32000,0,'sales');
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jurnal`
--

DROP TABLE IF EXISTS `jurnal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jurnal` (
  `jurnal_id` varchar(10) NOT NULL,
  `jurnal_date` date NOT NULL,
  `chart_no` int(11) NOT NULL,
  `chart_name` varchar(45) NOT NULL,
  `debit` double DEFAULT NULL,
  `credit` double DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jurnal`
--

LOCK TABLES `jurnal` WRITE;
/*!40000 ALTER TABLE `jurnal` DISABLE KEYS */;
INSERT INTO `jurnal` VALUES ('J1','1999-09-01',5110,'purchasing',100000,0,'a'),('J1','1999-09-01',5120,'purchasing discount',0,10000,'a'),('J1','1999-09-01',2051,'tax in',9000,0,'a'),('J1','1999-09-01',1010,'cash',0,99000,'a'),('J2','1999-09-12',4010,'sales income',0,200000,'a'),('J2','1999-09-12',1020,'bank',200000,0,'a'),('J3','1999-09-21',4010,'sales income',0,20000,''),('J3','1999-09-21',1020,'bank',20000,0,''),('J4','1999-09-18',5110,'purchasing',1000000,0,'a'),('J4','1999-09-18',1010,'cash',0,1000000,'a'),('J5','1999-09-25',5110,'purchasing',250000,0,'a'),('J5','1999-09-25',5120,'purchasing discount',0,25000,'a'),('J5','1999-09-25',2051,'tax in',22500,0,'a'),('J5','1999-09-25',1010,'cash',0,247500,'a'),('J6','1999-09-14',5110,'purchasing',500000,0,''),('J6','1999-09-14',1010,'cash',0,500000,''),('J7','1999-09-14',5110,'purchasing',1000,0,'a'),('J7','1999-09-14',5120,'purchasing discount',0,100,'a'),('J7','1999-09-14',2051,'tax in',90,0,'a'),('J7','1999-09-14',1010,'cash',0,990,'a'),('J1','2018-08-01',5110,'purchasing',100000,0,'Purchase Buku'),('J1','2018-08-01',5120,'purchasing discount',0,10000,'Purchase Buku'),('J1','2018-08-01',2051,'tax in',9000,0,'Purchase Buku'),('J1','2018-08-01',1010,'cash',0,99000,'Purchase Buku'),('J2','2018-08-02',4010,'sales income',0,5000,''),('J2','2018-08-02',1030,'account receivable',2500,0,''),('J2','2018-08-02',1010,'cash',2500,0,''),('J1','2017-07-01',5110,'purchasing',100000,0,'Purchase botol'),('J1','2017-07-01',5120,'purchasing discount',0,10000,'Purchase botol'),('J1','2017-07-01',2051,'tax in',9000,0,'Purchase botol'),('J1','2017-07-01',1010,'cash',0,99000,'Purchase botol'),('J1','2019-09-01',5110,'purchasing',100000,0,'purchase botol'),('J1','2019-09-01',5120,'purchasing discount',0,10000,'purchase botol'),('J1','2019-09-01',2051,'tax in',9000,0,'purchase botol'),('J1','2019-09-01',1010,'cash',0,99000,'purchase botol');
/*!40000 ALTER TABLE `jurnal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'joshua','joshua','joshua'),(2,'jordy','jordy','jordy'),(4,'felix','felix','felix'),(10,'admin','admin','admin'),(13,'ricky','ricky','ricky'),(14,'hardy','hardy','hardy'),(15,'albert','albert','albert');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `y_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` varchar(20) NOT NULL,
  `payment_type` varchar(10) NOT NULL,
  `jurnal_date` date NOT NULL,
  `jurnal_id` varchar(10) NOT NULL,
  `payment_percent` double NOT NULL,
  `payment_value` double NOT NULL,
  PRIMARY KEY (`y_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'Y1','CASH','2000-01-01','J1',40,44000),(2,'Y1','CREDIT','2000-01-01','J1',60,66000),(3,'Y2','CREDIT','2000-01-02','J2',0,200000),(4,'Y3','CASH','2000-01-03','J3',0,3000000),(5,'Y4','CASH','1999-09-19','J5',0,10000),(6,'Y6','CREDIT','1999-09-19','J7',0,200000),(7,'Y10','BANK','1999-09-29','J11',0,20000),(8,'Y1','Bank','2017-07-01','J1',0,10000),(9,'Y1','CASH','2011-11-01','J1',50,495000),(10,'Y1','CREDIT','2011-11-01','J1',50,495000),(11,'Y1','CASH','2012-12-01','J1',0,1000000),(12,'Y1','CASH','1997-07-01','J1',0,2000000),(13,'Y2','CREDIT','1997-07-05','J3',0,990000),(14,'Y1','CASH','1999-09-01','J1',0,99000),(15,'Y2','BANK','1999-09-12','J2',100,200000),(16,'Y2','BANK','1999-09-21','J3',100,20000),(17,'Y2','CASH','1999-09-18','J4',0,1000000),(18,'Y3','CASH','1999-09-25','J5',100,247500),(19,'Y4','CASH','1999-09-14','J6',0,500000),(20,'Y5','CASH','1999-09-14','J7',100,990),(21,'Y1','CASH','2018-08-01','J1',100,99000),(22,'Y1','CASH','2017-07-01','J1',100,99000),(23,'Y1','CASH','2019-09-01','J1',100,99000);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price` (
  `Jurnal_date` date NOT NULL,
  `Jurnal_id` varchar(45) NOT NULL,
  `Product_name` varchar(45) NOT NULL,
  `qty` int(10) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `value` int(10) unsigned NOT NULL,
  `type` varchar(45) NOT NULL,
  `people` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price`
--

LOCK TABLES `price` WRITE;
/*!40000 ALTER TABLE `price` DISABLE KEYS */;
INSERT INTO `price` VALUES ('2000-01-06','0','pen',0,10000,100000,'purchase','leonardy'),('2000-01-07','0','pen',0,1111,3333,'sales','leonardy'),('2000-01-09','0','pen',0,1000,5000,'purchase','leonardy'),('2000-01-10','0','pen',0,10000,310000,'purchase','leonardy'),('2000-01-13','0','book',0,1000,5000,'purchase','leonardy'),('2000-01-14','0','book',0,100000,4000000,'purchase','leonardy'),('2020-02-02','0','12',0,12,12,'12','12');
/*!40000 ALTER TABLE `price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(45) DEFAULT NULL,
  `product_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Botol','Bagus'),(3,'Pen','mantap'),(4,'Buku','tebel'),(7,'Pensil','tajam');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase`
--

DROP TABLE IF EXISTS `purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase` (
  `p_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jurnal_date` date NOT NULL,
  `jurnal_id` varchar(45) NOT NULL,
  `product_name` varchar(45) NOT NULL,
  `p_qty` int(10) unsigned NOT NULL,
  `p_price` int(10) unsigned NOT NULL,
  `p_value` int(10) unsigned NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase`
--

LOCK TABLES `purchase` WRITE;
/*!40000 ALTER TABLE `purchase` DISABLE KEYS */;
INSERT INTO `purchase` VALUES (1,'2000-01-06','J7','pen',10,10000,100000),(2,'2000-01-07','J8','pen',3,1111,3333);
/*!40000 ALTER TABLE `purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `det` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'Joshua','Jln.Ansari No.55','0812345678','1998-11-30'),(3,'Jordy','Jln.Ansari No.55','0812345678','1998-11-30'),(4,'Hardy','Jln.Ansari No.55','0812345678','1998-11-30'),(6,'Jo','Jln.Ansari No.55','0812345678','1998-11-28'),(7,'alim','Jln.Ansari No.55','0812345678','1998-11-30'),(8,'vin','Jln.Ansari No.55','0812345678','1998-11-19');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `det` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'123456789','Jln.Ansari No.55','KIKI','1998-11-30'),(2,'123456789','Jln.Ansari No.55','PISI','1998-11-30'),(3,'123456789','Jln.Ansari No.55','POSI','1998-11-30'),(4,'123456789','Jln.Ansari No.55','Hardy','1998-11-30');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system`
--

DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `system_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system_date` date NOT NULL,
  `system_jurnal` int(10) unsigned NOT NULL,
  `system_sales` varchar(5) DEFAULT NULL,
  `system_pur` varchar(5) NOT NULL,
  `system_pay` varchar(5) NOT NULL,
  PRIMARY KEY (`system_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system`
--

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES (1,'2017-10-01',2,NULL,'1','1'),(2,'2017-10-01',2,NULL,'1','1'),(3,'2017-10-01',2,NULL,'1','1'),(4,'2017-10-01',2,NULL,'1','1'),(5,'1998-08-01',7,NULL,'1','1'),(6,'1998-10-01',1,NULL,'1','1'),(7,'1998-08-01',7,NULL,'1','1'),(8,'2017-07-01',2,'1','2','2'),(9,'2000-10-01',2,NULL,'1','1'),(10,'2010-10-01',2,NULL,'1','1'),(11,'1998-08-01',7,NULL,'1','1'),(12,'1999-09-01',8,'1','6','6'),(13,'1999-09-01',8,'1','6','6'),(14,'1999-09-01',8,'1','6','6'),(15,'1999-09-01',8,'1','6','6'),(16,'1999-09-01',8,'1','6','6'),(17,'1999-09-01',8,'1','6','6'),(18,'1999-09-01',8,'1','6','6'),(19,'2017-07-01',2,'1','2','2'),(20,'2011-11-01',4,'1','2','2'),(21,'1999-09-01',8,'1','6','6'),(22,'2012-12-01',3,'1','2','2'),(23,'1998-09-01',1,'1','1','1'),(24,'2017-07-01',2,'1','2','2'),(25,'2017-12-01',1,'1','1','1'),(26,'1997-07-01',4,'1','3','3'),(27,'1997-07-01',4,'1','3','3'),(28,'1997-07-01',4,'1','3','3'),(29,'1997-07-01',4,'1','3','3'),(30,'1997-07-01',1,'1','1','1'),(31,'1999-09-01',8,'1','6','6'),(32,'1999-09-01',8,'1','6','6'),(33,'2000-07-01',1,'1','1','1'),(34,'2018-08-01',3,'1','2','2'),(35,'2017-07-01',2,'1','2','2'),(36,'2019-09-01',2,'1','2','2');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-08 20:00:06
