
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A S U S
 */
public class PnlPL extends javax.swing.JPanel {

    /**
     * Creates new form PnlPL
     */
     String date;
    float finalValue = 0;

    /**
     * Creates new form ProfitLoss
     */
    public void setTf() {
        jTextField1.setText(DataBase.date);
    }

    public float getProfitLoss(String date) {
        setProfitLoss(date);
        return finalValue;
    }
    DefaultTableModel model;
    public PnlPL() {
        initComponents();
          model = (DefaultTableModel) jTable2.getModel();
    }

     public void setProfitLoss(String date) {

//        DefaultTableModel model1 = (DefaultTableModel) jTable2.getModel();
//        DefaultTableModel model2 = (DefaultTableModel) jTable3.getModel();
        model.setRowCount(0);
        ArrayList<String> chartList = new ArrayList<>();
        Statement st = DataBase.getStatement();
        ResultSet rs;
        int totalSales = 0, totalFinalSales = 0, totalCogs = 0;
        float totalFinalCogs = 0, totalExpend = 0, totalFinalExpend = 0;
        try {
            model.addRow(new Object[]{"SALES REVENUE"});
            st = DataBase.getStatement();
            rs = st.executeQuery("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '4%'");
            System.out.println("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '4%'");
            while (rs.next()) {
                chartList.add(rs.getString("chart_name"));
            }
            for (String a : chartList) {
                rs = st.executeQuery("select chart_name, sum(credit)-sum(debit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                System.out.println("select chart_name, sum(credit)-sum(debit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                while (rs.next()) {
                    int sales = rs.getInt("sum(credit)-sum(debit)");
                    totalSales += sales;
                    model.addRow(new Object[]{a,  totalSales});
                    totalFinalSales += totalSales;
                    totalSales = 0;
                }
            }
            model.addRow(new Object[]{"SUM", "", totalFinalSales});
//             model.addRow(new Object[]{"SUM", "", totalFinalSales});
            model.addRow(new Object[]{});
            model.addRow(new Object[]{"COGS"});
            chartList.clear();
            //for cogs
            rs = st.executeQuery("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '5%'");
            System.out.println("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '5%'");
            while (rs.next()) {
                chartList.add(rs.getString("chart_name"));
            }
            for (String a : chartList) {
                rs = st.executeQuery("select chart_name, sum(debit)-sum(credit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                System.out.println("select chart_name, sum(debit)-sum(credit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                while (rs.next()) {
                    System.out.println(a);
                    int cogs = rs.getInt("sum(debit)-sum(credit)");
                    totalCogs += cogs;
                    model.addRow(new Object[]{a,  totalCogs});
                    totalFinalCogs += totalCogs;
                    totalCogs = 0;
                    System.out.println(totalFinalCogs);
                }
            }
            PnlInventory in = new PnlInventory();
            int aa = (int) in.getTotalFinal(date);
            model.addRow(new Object[]{"ending inventory", aa});
            totalFinalCogs = (totalFinalCogs - aa);
            System.out.println(totalFinalCogs + in.getTotalFinal(date));
            model.addRow(new Object[]{"SUM", "",totalFinalCogs});
            model.addRow(new Object[]{});
            model.addRow(new Object[]{"OPERASIONAL EXPENDICUTE"});
            chartList.clear();

            //for expenditure
            rs = st.executeQuery("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '6%'");
            System.out.println("select distinct chart_name from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_id like '6%'");
            while (rs.next()) {
                chartList.add(rs.getString("chart_name"));
            }
            for (String a : chartList) {
                rs = st.executeQuery("select chart_name, sum(debit)-sum(credit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                System.out.println("select chart_name, sum(debit)-sum(credit) from jurnal natural join chart where jurnal_date like '" + date + "-%' and chart_name like '" + a + "'");
                while (rs.next()) {
                    int expend = rs.getInt("sum(debit)-sum(credit)");
                    totalExpend += expend;
                    model.addRow(new Object[]{a, "", totalExpend});
                    totalFinalExpend += totalExpend;
                    totalExpend = 0;
                }
            }
            model.addRow(new Object[]{"SUM", totalFinalExpend});
            model.addRow(new Object[]{});
            chartList.clear();
            finalValue = totalFinalSales - totalFinalCogs - totalFinalExpend;
            model.addRow(new Object[]{"", "TOTAL",  finalValue});
            Double d = new Double(finalValue);
//            jLabel5.setText(Double.toString(d));
            jLabel5.setText(String.format("Rp.%,.2f", finalValue));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setText("NET PROFIT : ");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N

        jTable2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "VALUE", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setRowHeight(25);
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1162, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(92, 92, 92))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(131, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1304, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 722, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        date = jTextField1.getText();
        setProfitLoss(date);
        DataBase.date = date;
        finalValue = 0;
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        date = jTextField1.getText();
        setProfitLoss(date);
        DataBase.date = date;
        finalValue = 0;
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
