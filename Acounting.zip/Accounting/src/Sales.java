
import de.javasoft.plaf.synthetica.SyntheticaBlueLightLookAndFeel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import util.DbConn;
import util.Sutil;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author A S U S
 */
public class Sales extends javax.swing.JFrame {

    /**
     * Creates new form Sales
     */
    
    public Sales() {
        initComponents();
        setLocationRelativeTo(null);
        databaseConnection();
        setComboCustomer();
        setComboPayment();
        setComboProduct();
      
      
         jTable1.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(cProduct));
          jTable2.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(cPayment));
    }
    private Connection conn;
      JComboBox cProduct = new JComboBox(); //combo box
    JComboBox cPayment = new JComboBox();

   
    private void databaseConnection() {
        try {
            Class.forName(DbConn.JDBC_CLASS);
            conn = DriverManager.getConnection(DbConn.JDBC_URL,
                    DbConn.JDBC_USERNAME,
                    DbConn.JDBC_PASSWORD);

            if (conn != null) {
                System.out.println("Connected to DB!\n");

            }
        } catch (SQLException | ClassNotFoundException ex) {
            System.out.println("Error:\n" + ex.getLocalizedMessage());
        }

        
    }
    public void setComboProduct() {
        try {
            Statement st = DataBase.getStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM product");
            while (rs.next()) {
                cProduct.addItem(rs.getString("product_name"));
            }
            cProduct.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
//                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    try {
                        if (DataBase.jurnalShow == 1) {
                            jTable1.setValueAt(cProduct.getSelectedItem(), jTable1.getSelectedRow(), 0);
                        }
                      

                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }
    public void setComboPayment() {
        cPayment.addItem("cash");
        cPayment.addItem("credit");
    
        cPayment.addItem("bank");
        cPayment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                try {
                    if (DataBase.jurnalShow == 1) {
                        jTable2.setValueAt(cPayment.getSelectedItem(),jTable2.getSelectedRow(), 0 );
                    }
//                    if (DataBase.jurnalShow == 2) {
//                        tPur2.setValueAt(cPayment.getSelectedItem(), tPur2.getSelectedRow(), 1);
//                    }
//                    if (DataBase.jurnalShow == 4) {
//                        tExpend2.setValueAt(cPayment.getSelectedItem(), tExpend2.getSelectedRow(), 1);
//                    }
                } catch (Exception ee) {
                    ee.printStackTrace();
                }
            }
        });
    }
//     public void setComboPayment() {
//        cPayment.addItem("cash");
//        cPayment.addItem("credit");
//        cPayment.addItem("giro");
//        cPayment.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
////                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//                try {
//                    if (DataBase.jurnalShow == 1) {
//                        tsales2.setValueAt(cPayment.getSelectedItem(), tsales2.getSelectedRow(), 1);
//                    }
//                    if (DataBase.jurnalShow == 2) {
//                        tPur2.setValueAt(cPayment.getSelectedItem(), tPur2.getSelectedRow(), 1);
//                    }
//                } catch (Exception ee) {
//                    ee.printStackTrace();
//                }
//            }
//        });
//    }

//    public String getDate() {
//
//        String dateStr;
//        DateFormat f = new SimpleDateFormat("yyyy-MM-dd");
//        dateStr = f.format(jDate.getDate());
//        System.out.println(dateStr);
//        return dateStr;
//
//    }
    public void setComboCustomer() {
        try {
            String sql = "SELECT * from customer ;";
            PreparedStatement pstatement = conn.prepareStatement(sql);

            ResultSet rs = pstatement.executeQuery();
            if (rs.isBeforeFirst()) { // check is resultset not empty

                while (rs.next()) {
                    cSalesTo.addItem(rs.getString("company"));
                }
            } else {
                Sutil.msg(this, "Record empty.");
            }
            rs.close();
            pstatement.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        bRemoveProduct = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtDesc = new javax.swing.JTextField();
        bAddProdcut = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bSubmit = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jText = new javax.swing.JTextField();
        cSalesTo = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        pnlPurchasee1 = new PnlPurchasee();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        bRemoveProduct.setText("REMOVE");
        bRemoveProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRemoveProductActionPerformed(evt);
            }
        });

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Description");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Customer");

        bAddProdcut.setText("ADD PRODUCT");
        bAddProdcut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAddProdcutActionPerformed(evt);
            }
        });

        jButton4.setText("REMOVE ");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "PAYMENT", "PERCENT"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable2.setMaximumSize(new java.awt.Dimension(2147483647, 75));
        jTable2.setMinimumSize(new java.awt.Dimension(45, 50));
        jTable2.setPreferredSize(new java.awt.Dimension(225, 75));
        jTable2.setRowHeight(25);
        jScrollPane1.setViewportView(jTable2);

        jTable1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "PRODUCT", "QTY", "PRICE", "DISCOUNT", "TAX"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setMaximumSize(new java.awt.Dimension(2147483647, 250));
        jTable1.setMinimumSize(new java.awt.Dimension(75, 60));
        jTable1.setPreferredSize(new java.awt.Dimension(375, 250));
        jTable1.setRequestFocusEnabled(false);
        jTable1.setRowHeight(25);
        jScrollPane3.setViewportView(jTable1);

        bSubmit.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        bSubmit.setText("Confirm");
        bSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSubmitActionPerformed(evt);
            }
        });

        jButton2.setText("MORE PAYMENT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel25.setText("Date");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Refresh_icon.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jText, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cSalesTo, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(453, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(304, 304, 304))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(bSubmit)
                        .addGap(417, 417, 417))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(bAddProdcut, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(bRemoveProduct, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jScrollPane3))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton2)
                                .addComponent(jButton4))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cSalesTo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 186, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(txtDesc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(bSubmit)
                .addGap(91, 91, 91))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(93, 93, 93)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(bAddProdcut)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(bRemoveProduct)))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jButton2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jButton4)))
                    .addContainerGap(87, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Sales", jPanel1);
        jTabbedPane1.addTab("Purchase", pnlPurchasee1);

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("New Jurnal");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        dispose();
         
        new AMain().setDialog();
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.addRow(new Object[]{});
    }//GEN-LAST:event_jButton2ActionPerformed

    private void bSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSubmitActionPerformed
        try {
            int qty = 0;
            double price = 0, total = 0, discount = 0, tax = 0, pay = 0, totalvalue = 0, totalpay = 0, taxper = 0, discountper = 0;
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                for (int j = 0; j < jTable1.getColumnCount(); j++) {

                    if (j == 1) {
                        if (jTable1.getModel().getValueAt(i, j) != null) {
                            qty = (Integer) jTable1.getModel().getValueAt(i, j);
                        } else {
                            JOptionPane.showMessageDialog(this, "Pleae Entry Qty");
                            break;
                        }
                    }
                    if (j == 2) {
                        if (jTable1.getModel().getValueAt(i, j) != null) {
                            price = (Double) jTable1.getModel().getValueAt(i, j);
                            total = price;
                            DataBase.setExecuteUpdate("INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                    + "','4010','sales income',0," + total * qty + ",'" + txtDesc.getText() + "')");
                            System.out.println("oke");

                        } else {
                            JOptionPane.showMessageDialog(this, "Pleae Entry Price");
                            break;
                        }
                    }
                    if (j == 3) {
                        if (jTable1.getModel().getValueAt(i, j) != null) {
                            discountper = (Double) jTable1.getModel().getValueAt(i, j);
                            discount = price * discountper / 100;
                            String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                    + "','4020','sales discount'," + discount * qty + ",0,'" + txtDesc.getText() + "')";
                            System.out.println(sql);
                            DataBase.setExecuteUpdate(sql);
                        } else {
                            discount = 0;
                        }
                    }
                    if (j == 4) {
                        if (jTable1.getModel().getValueAt(i, j) != null) {
                            taxper = (Double) jTable1.getModel().getValueAt(i, j);
                            tax = (price - discount) * taxper / 100;
                            String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                    + "','1050','tax out',0," + tax * qty + ",'" + txtDesc.getText() + "')";
                            System.out.println(sql);
                            DataBase.setExecuteUpdate(sql);
                        } else {
                            tax = 0;
                        }
                    }
                }
                totalvalue = (total - discount + tax) * qty;

                DataBase.setExecuteUpdate("INSERT INTO INVENTORY VALUES('S" + DataBase.salesId + "','" + DataBase.jurnalDate + "-" + jText.getText() + "', 'J" + DataBase.jurnalId + "','"
                        + jTable1.getModel().getValueAt(i, 0) + "',0,0,0," + qty + "," + (total - discount + tax) + ","
                        + totalvalue + ",'sales','" + cSalesTo.getSelectedItem() + "'," + discountper + "," + taxper + "," + price + ")");
                System.out.println("INSERT INTO INVENTORY VALUES('S" + DataBase.salesId + "','" + DataBase.jurnalDate + "-" + jText.getText() + "', 'J" + DataBase.jurnalId + "','"
                        + jTable1.getModel().getValueAt(i, 0) + "',0,0,0," + qty + "," + (total - discount + tax) + ","
                        + totalvalue + ",'sales','" + cSalesTo.getSelectedItem() + "'," + discountper + "," + taxper + "," + price + ")");

                DataBase.setExecuteUpdate("INSERT INTO INVOICE(INVENTORY_ID ,JURNAL_DATE, JURNAL_ID,PAYMENT_ID) VALUES('S" + DataBase.salesId + "','" + DataBase.jurnalDate + "-"
                        + jText.getText() + "', 'J" + DataBase.jurnalId + "','Y" + DataBase.payId + "')");
                System.out.println("INSERT INTO INVOICE(INVENTORY_ID ,JURNAL_DATE, JURNAL_ID,PAYMENT_ID) VALUES('S" + DataBase.salesId + "','" + DataBase.jurnalDate + "-"
                        + jText.getText() + "', 'J" + DataBase.jurnalId + "','Y" + DataBase.payId + "')");
                pay += totalvalue;
                discount = 0;
                tax = 0;
                System.out.println(totalvalue + " " + pay);
            }//SALES PAYMENT SUBMIT
            for (int i = 0; i < jTable2.getRowCount(); i++) {
                for (int j = 0; j < jTable2.getColumnCount(); j++) {
                    if (j == 1) {
                        System.out.println("i ke berepa" + i);
                        System.out.println("col =" + jTable2.getModel().getValueAt(i, 0));
                        if (jTable2.getModel().getValueAt(i, 0).equals("cash")) {
                            if (pay != 0) {
                                if (jTable2.getModel().getValueAt(i, j) != null) {
                                    totalpay = pay * (Integer) jTable2.getModel().getValueAt(i, j) / 100;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1010','cash'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    System.out.println(totalpay);
                                    DataBase.setExecuteUpdate(sql);
                                }
                                if (jTable2.getModel().getValueAt(i, j) == null) {
                                    totalpay = pay;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1010','cash'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    DataBase.setExecuteUpdate(sql);
                                }
                            }
                        }
                        if (jTable2.getModel().getValueAt(i, 0).equals("credit")) {
                            if (pay != 0) {
                                if (jTable2.getModel().getValueAt(i, j) != null) {
                                    totalpay = pay * (Integer) jTable2.getModel().getValueAt(i, j) / 100;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1030','account receivable'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    DataBase.setExecuteUpdate(sql);
                                }
                                if (jTable2.getModel().getValueAt(i, j) == null) {
                                    totalpay = pay;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1030','account receivable'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    DataBase.setExecuteUpdate(sql);
                                }

                            }
                        }
                        if (jTable2.getModel().getValueAt(i, 0).equals("bank")) {
                            if (pay != 0) {
                                if (jTable2.getModel().getValueAt(i, j) != null) {
                                    totalpay = pay * (Integer) jTable2.getModel().getValueAt(i, j) / 100;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1020','bank'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    DataBase.setExecuteUpdate(sql);
                                    DataBase.setExecuteUpdate("INSERT INTO PAYMENT(PAYMENT_ID, PAYMENT_TYPE, JURNAL_DATE, JURNAL_ID, PAYMENT_PERCENT, PAYMENT_VALUE)"
                                            + " VALUES ('Y" + DataBase.payId + "','BANK','" + DataBase.jurnalDate + "-" + jText.getText() + "','J" + DataBase.jurnalId
                                            + "'," + jTable2.getModel().getValueAt(i, j) + "," + totalpay + ")");
                                    System.out.println("INSERT INTO PAYMENT(PAYMENT_ID, PAYMENT_TYPE, JURNAL_DATE, JURNAL_ID, PAYMENT_PERCENT, PAYMENT_VALUE)"
                                            + " VALUES ('Y" + DataBase.payId + "','bank','" + DataBase.jurnalDate + "-" + jText.getText() + "','J" + DataBase.jurnalId
                                            + "'," + jTable2.getModel().getValueAt(i, j) + "," + totalpay + ")");

                                }
                                if (jTable2.getModel().getValueAt(i, j) == null) {
                                    totalpay = pay;
                                    String sql = "INSERT INTO JURNAL VALUES('J" + DataBase.jurnalId + "','" + DataBase.jurnalDate + "-" + jText.getText()
                                            + "','1020','bank'," + totalpay + ",0,'" + txtDesc.getText() + "')";
                                    System.out.println(sql);
                                    DataBase.setExecuteUpdate(sql);
                                    DataBase.setExecuteUpdate("INSERT INTO PAYMENT(PAYMENT_ID, PAYMENT_TYPE, JURNAL_DATE, JURNAL_ID, PAYMENT_PERCENT, PAYMENT_VALUE)"
                                            + " VALUES ('Y" + DataBase.payId + "','Bank','" + DataBase.jurnalDate + "-" + jText.getText() + "','J" + DataBase.jurnalId
                                            + "'," + 0 + "," + totalpay + ")");
                                    System.out.println("INSERT INTO PAYMENT(PAYMENT_ID, PAYMENT_TYPE, JURNAL_DATE, JURNAL_ID, PAYMENT_PERCENT, PAYMENT_VALUE)"
                                            + " VALUES ('Y" + DataBase.payId + "','Bank','" + DataBase.jurnalDate + "-" + jText.getText() + "','J" + DataBase.jurnalId
                                            + "'," + 0 + "," + totalpay + ")");

                                }
                            }
                        }
                    }
                }
            }

            //        System.out.println(qty + " " + price + " " + discount+" "+tax);
            System.out.println(pay);
            System.out.println(total);
            //to add auto id
            DataBase.jurnalId++;
            DataBase.setExecuteUpdate("UPDATE SYSTEM SET SYSTEM_JURNAL=" + DataBase.jurnalId + ", SYSTEM_SALES =" + DataBase.salesId + " , SYSTEM_PUR = " + DataBase.purId
                    + ",  SYSTEM_PAY = " + DataBase.payId + " WHERE SYSTEM_DATE ='" + DataBase.jurnalDate + "-1';");
            System.out.println("UPDATE SYSTEM SET SYSTEM_JURNAL=" + DataBase.jurnalId + ", SYSTEM_SALES =" + DataBase.salesId + " , SYSTEM_PUR = " + DataBase.purId
                    + ",  SYSTEM_PAY = " + DataBase.payId + " WHERE SYSTEM_DATE ='" + DataBase.jurnalDate + "-1';");
            txtDesc.setText("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
        //clear text

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        model.addRow(new Object[]{});
        DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel();
        model2.setRowCount(0);
        model2.addRow(new Object[]{});
    }//GEN-LAST:event_bSubmitActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
            model.removeRow(jTable2.getSelectedRow());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void bAddProdcutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAddProdcutActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.addRow(new Object[]{});
    }//GEN-LAST:event_bAddProdcutActionPerformed

    private void bRemoveProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRemoveProductActionPerformed
        try {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.removeRow(jTable1.getSelectedRow());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }//GEN-LAST:event_bRemoveProductActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
  cProduct.removeAllItems();
         cSalesTo.removeAllItems();
         setComboCustomer();
        setComboProduct();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAddProdcut;
    private javax.swing.JButton bRemoveProduct;
    private javax.swing.JButton bSubmit;
    private javax.swing.JComboBox<String> cSalesTo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jText;
    private PnlPurchasee pnlPurchasee1;
    public static javax.swing.JTextField txtDesc;
    // End of variables declaration//GEN-END:variables

static {
        try {
            UIManager.setLookAndFeel(new SyntheticaBlueLightLookAndFeel());
    
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(FrmCustome.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(FrmCustome.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
