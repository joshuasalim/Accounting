/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author A S U S
 */
public class DbConn {
    
    public static final String JDBC_CLASS = "com.mysql.jdbc.Driver";
    public static final String JDBC_URL = "jdbc:mysql://localhost:3306/accounting";
    public static final String JDBC_USERNAME = "root";
    public static final String JDBC_PASSWORD ="root";
}
